Image resources used to fulfill publishing requirements of an App to Google
Play in order to quickly get the sample application running.

Your app only needs to be published to the Alpha channel and you should always
add Google Accounts on your test devices to the App's list of tester in your
Google Play store entry.